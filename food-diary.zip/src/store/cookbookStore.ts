import { create } from "zustand"
import { createId } from "@/utils/id"
import { addDays, startOfWeek, toISODate, weekIdFromStartDate } from "@/utils/date"
import { readLocalStorage, safeJsonParse, writeLocalStorage } from "@/utils/storage"
import type { CookbookData, DishLog, Recipe, StorageShape, Tag } from "@/store/cookbookTypes"
const STORAGE_KEY = "cookbook.v1"

function nowIso() {
  return new Date().toISOString()
}

function debounce<T extends (...args: any[]) => void>(fn: T, waitMs: number) {
  let t: number | undefined
  return (...args: Parameters<T>) => {
    if (t) window.clearTimeout(t)
    t = window.setTimeout(() => fn(...args), waitMs)
  }
}

function createEmptyData(): CookbookData {
  return { recipes: {}, tags: {}, recipeTags: [], weeks: {}, days: {}, dishes: {} }
}

function normalizeData(raw: CookbookData): CookbookData {
  const weeks: CookbookData["weeks"] = { ...raw.weeks }
  for (const [id, w] of Object.entries(weeks)) {
    if (!("ingredientHave" in w) || !w.ingredientHave) weeks[id] = { ...w, ingredientHave: {} } as any
  }

  const dishes: CookbookData["dishes"] = { ...raw.dishes }
  for (const [id, d] of Object.entries(dishes)) {
    const hasLines = "ingredientLines" in d && Array.isArray((d as any).ingredientLines)
    if (!hasLines) {
      const fromRecipe = d.recipeId ? raw.recipes[d.recipeId]?.ingredientLines ?? [] : []
      dishes[id] = { ...(d as any), ingredientLines: fromRecipe } as any
    }
  }

  return { ...raw, weeks, dishes }
}

function buildInitialData(): CookbookData {
  const data = createEmptyData()
  const t = nowIso()

  const tagHome: Tag = { id: createId("tag"), name: "家常", color: "#7c9a7a" }
  const tagQuick: Tag = { id: createId("tag"), name: "快手", color: "#c85b4a" }
  data.tags[tagHome.id] = tagHome
  data.tags[tagQuick.id] = tagQuick

  const recipe1: Recipe = {
    id: createId("recipe"),
    title: "番茄炒蛋",
    ingredientLines: ["鸡蛋 2 个", "番茄 2 个", "盐 适量", "糖 一小撮（可选）", "葱花 少许"],
    stepLines: ["鸡蛋打散，锅热油滑炒至凝固后盛出", "番茄下锅炒出汁，加盐与一小撮糖", "倒回鸡蛋翻炒均匀，出锅撒葱花"],
    notes: "番茄先加盐更出汁；想要更滑可在蛋液里加少许水。",
    servings: 2,
    totalMinutes: 12,
    difficulty: "简单",
    lastCookedAt: null,
    createdAt: t,
    updatedAt: t,
  }
  data.recipes[recipe1.id] = recipe1
  data.recipeTags.push({ recipeId: recipe1.id, tagId: tagHome.id }, { recipeId: recipe1.id, tagId: tagQuick.id })

  const weekStart = startOfWeek(new Date())
  const weekId = weekIdFromStartDate(weekStart)
  data.weeks[weekId] = { weekId, weekStartDate: toISODate(weekStart), summary: "", ingredientHave: {}, createdAt: t, updatedAt: t }

  for (let i = 0; i < 7; i++) {
    const date = toISODate(addDays(weekStart, i))
    const dayId = `day_${weekId}_${date}`
    data.days[dayId] = { id: dayId, weekId, date }
  }

  return data
}

function loadFromStorage(): CookbookData | null {
  const raw = readLocalStorage(STORAGE_KEY)
  if (!raw) return null
  const parsed = safeJsonParse<StorageShape>(raw)
  if (!parsed.ok) return null
  if (!parsed.value || parsed.value.version !== 1 || !parsed.value.data) return null
  return normalizeData(parsed.value.data)
}

function saveToStorage(data: CookbookData) {
  const payload: StorageShape = { version: 1, data }
  writeLocalStorage(STORAGE_KEY, JSON.stringify(payload))
}

export type CookbookStore = {
  data: CookbookData
  actions: {
    ensureWeekByDate: (isoDate: string) => string
    addDish: (isoDate: string, input: { title: string; recipeId?: string | null; tweakNote?: string }) => string
    updateDish: (dishId: string, patch: { title?: string; recipeId?: string | null; tweakNote?: string; ingredientLines?: string[] }) => void
    removeDish: (dishId: string) => void

    createRecipe: (input: Omit<Recipe, "id" | "createdAt" | "updatedAt" | "lastCookedAt"> & { lastCookedAt?: string | null }) => string
    upsertRecipe: (recipeId: string, input: Omit<Recipe, "id" | "createdAt" | "updatedAt" | "lastCookedAt"> & { lastCookedAt?: string | null }) => string
    updateRecipe: (recipeId: string, patch: Partial<Omit<Recipe, "id" | "createdAt">>) => void
    deleteRecipe: (recipeId: string) => void
    markRecipeCooked: (recipeId: string, isoDate: string) => void
    setRecipeTagNames: (recipeId: string, tagNames: string[]) => void

    setWeekSummary: (weekId: string, summary: string) => void
    setWeekIngredientHave: (weekId: string, ingredient: string, have: boolean) => void
    exportJsonText: () => string
    importJsonText: (jsonText: string) => { ok: true } | { ok: false; error: string }
    reset: () => void
  }
}

export const useCookbookStore = create<CookbookStore>((set, get) => ({
  data: loadFromStorage() ?? buildInitialData(),
  actions: {
    ensureWeekByDate: (isoDate) => {
      const t = nowIso()
      const weekStart = startOfWeek(new Date(`${isoDate}T00:00:00`))
      const weekId = weekIdFromStartDate(weekStart)

      set((state) => {
        if (state.data.weeks[weekId]) return state
        const next: CookbookData = {
          ...state.data,
          weeks: {
            ...state.data.weeks,
            [weekId]: { weekId, weekStartDate: toISODate(weekStart), summary: "", ingredientHave: {}, createdAt: t, updatedAt: t },
          },
          days: { ...state.data.days },
        }

        for (let i = 0; i < 7; i++) {
          const date = toISODate(addDays(weekStart, i))
          const dayId = `day_${weekId}_${date}`
          next.days[dayId] = { id: dayId, weekId, date }
        }
        return { data: next }
      })

      return weekId
    },
    addDish: (isoDate, input) => {
      const weekId = get().actions.ensureWeekByDate(isoDate)
      const dayId = `day_${weekId}_${isoDate}`
      const dishId = createId("dish")
      const t = nowIso()
      const ingredientLines = input.recipeId ? get().data.recipes[input.recipeId]?.ingredientLines ?? [] : []

      set((state) => ({
        data: {
          ...state.data,
          dishes: {
            ...state.data.dishes,
            [dishId]: {
              id: dishId,
              dayLogId: dayId,
              title: input.title.trim() || "未命名菜品",
              recipeId: input.recipeId ?? null,
              tweakNote: input.tweakNote ?? "",
              ingredientLines,
              createdAt: t,
            },
          },
        },
      }))

      return dishId
    },
    updateDish: (dishId, patch) => {
      set((state) => {
        const current = state.data.dishes[dishId]
        if (!current) return state
        return {
          data: {
            ...state.data,
            dishes: {
              ...state.data.dishes,
              [dishId]: {
                ...current,
                title: patch.title !== undefined ? (patch.title.trim() || "未命名菜品") : current.title,
                recipeId: patch.recipeId !== undefined ? patch.recipeId : current.recipeId,
                tweakNote: patch.tweakNote !== undefined ? patch.tweakNote : current.tweakNote,
                ingredientLines: patch.ingredientLines !== undefined ? patch.ingredientLines : current.ingredientLines,
              },
            },
          },
        }
      })
    },
    removeDish: (dishId) => {
      set((state) => {
        if (!state.data.dishes[dishId]) return state
        const nextDishes = { ...state.data.dishes }
        delete nextDishes[dishId]
        return { data: { ...state.data, dishes: nextDishes } }
      })
    },
    createRecipe: (input) => {
      const recipeId = createId("recipe")
      return get().actions.upsertRecipe(recipeId, input)
    },
    upsertRecipe: (recipeId, input) => {
      const t = nowIso()
      set((state) => {
        const existing = state.data.recipes[recipeId]
        const createdAt = existing?.createdAt ?? t
        const recipe: Recipe = { id: recipeId, ...input, lastCookedAt: input.lastCookedAt ?? null, createdAt, updatedAt: t }
        return { data: { ...state.data, recipes: { ...state.data.recipes, [recipeId]: recipe } } }
      })
      return recipeId
    },
    updateRecipe: (recipeId, patch) => {
      const t = nowIso()
      set((state) => {
        const current = state.data.recipes[recipeId]
        if (!current) return state
        const next: Recipe = { ...current, ...patch, id: recipeId, createdAt: current.createdAt, updatedAt: t }
        return { data: { ...state.data, recipes: { ...state.data.recipes, [recipeId]: next } } }
      })
    },
    deleteRecipe: (recipeId) => {
      set((state) => {
        if (!state.data.recipes[recipeId]) return state
        const nextRecipes = { ...state.data.recipes }
        delete nextRecipes[recipeId]
        const nextRecipeTags = state.data.recipeTags.filter((rt) => rt.recipeId !== recipeId)
        const nextDishes: Record<string, DishLog> = {}
        for (const [id, dish] of Object.entries(state.data.dishes)) {
          nextDishes[id] = dish.recipeId === recipeId ? { ...dish, recipeId: null } : dish
        }
        return { data: { ...state.data, recipes: nextRecipes, recipeTags: nextRecipeTags, dishes: nextDishes } }
      })
    },
    markRecipeCooked: (recipeId, isoDate) => {
      const t = nowIso()
      set((state) => {
        const current = state.data.recipes[recipeId]
        if (!current) return state
        return { data: { ...state.data, recipes: { ...state.data.recipes, [recipeId]: { ...current, lastCookedAt: isoDate, updatedAt: t } } } }
      })
    },
    setRecipeTagNames: (recipeId, tagNames) => {
      const palette = ["#7c9a7a", "#c85b4a", "#4d7ea8", "#b07aa1", "#d2a24c", "#6d5f53"]
      const cleaned = Array.from(new Set(tagNames.map((t) => t.trim()).filter(Boolean)))
      set((state) => {
        if (!state.data.recipes[recipeId]) return state
        const tags = { ...state.data.tags }
        const nextRecipeTags = state.data.recipeTags.filter((rt) => rt.recipeId !== recipeId)
        for (const name of cleaned) {
          const existing = Object.values(tags).find((t) => t.name === name)
          const tagId = existing
            ? existing.id
            : (() => {
                const id = createId("tag")
                const color = palette[Object.keys(tags).length % palette.length]
                tags[id] = { id, name, color }
                return id
              })()
          nextRecipeTags.push({ recipeId, tagId })
        }
        return { data: { ...state.data, tags, recipeTags: nextRecipeTags } }
      })
    },
    setWeekSummary: (weekId, summary) => {
      const t = nowIso()
      set((state) => {
        const current = state.data.weeks[weekId]
        if (!current) return state
        return { data: { ...state.data, weeks: { ...state.data.weeks, [weekId]: { ...current, summary, updatedAt: t } } } }
      })
    },
    setWeekIngredientHave: (weekId, ingredient, have) => {
      const key = ingredient.trim()
      if (!key) return
      const t = nowIso()
      set((state) => {
        const current = state.data.weeks[weekId]
        if (!current) return state
        const nextMap = { ...(current.ingredientHave ?? {}) }
        if (have) nextMap[key] = true
        else delete nextMap[key]
        return { data: { ...state.data, weeks: { ...state.data.weeks, [weekId]: { ...current, ingredientHave: nextMap, updatedAt: t } } } }
      })
    },
    exportJsonText: () => {
      const payload: StorageShape = { version: 1, data: get().data }
      return JSON.stringify(payload, null, 2)
    },
    importJsonText: (jsonText) => {
      const parsed = safeJsonParse<StorageShape>(jsonText)
      if (!parsed.ok) {
        return { ok: false, error: (parsed as { ok: false; error: string }).error }
      }
      if (!parsed.value || parsed.value.version !== 1 || !parsed.value.data) return { ok: false, error: "不支持的备份版本" }
      set({ data: normalizeData(parsed.value.data) })
      return { ok: true }
    },
    reset: () => set({ data: buildInitialData() }),
  },
}))
const debouncedPersist = typeof window === "undefined" ? null : debounce(saveToStorage, 350)
if (debouncedPersist) useCookbookStore.subscribe((state) => debouncedPersist(state.data))
