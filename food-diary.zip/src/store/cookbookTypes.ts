export type Recipe = {
  id: string
  title: string
  ingredientLines: string[]
  stepLines: string[]
  notes: string
  servings: number
  totalMinutes: number
  difficulty: string
  lastCookedAt: string | null
  createdAt: string
  updatedAt: string
}

export type Tag = {
  id: string
  name: string
  color: string
}

export type RecipeTag = {
  recipeId: string
  tagId: string
}

export type WeekLog = {
  weekId: string
  weekStartDate: string
  summary: string
  ingredientHave: Record<string, boolean>
  createdAt: string
  updatedAt: string
}

export type DayLog = {
  id: string
  weekId: string
  date: string
}

export type DishLog = {
  id: string
  dayLogId: string
  title: string
  recipeId: string | null
  tweakNote: string
  ingredientLines: string[]
  createdAt: string
}

export type CookbookData = {
  recipes: Record<string, Recipe>
  tags: Record<string, Tag>
  recipeTags: RecipeTag[]
  weeks: Record<string, WeekLog>
  days: Record<string, DayLog>
  dishes: Record<string, DishLog>
}

export type StorageShape = {
  version: 1
  data: CookbookData
}
