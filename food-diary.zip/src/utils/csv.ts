function escapeCsvCell(value: string) {
  const needsQuote = /[",\n\r]/.test(value)
  const escaped = value.replace(/"/g, '""')
  return needsQuote ? `"${escaped}"` : escaped
}

export function toCsv(headers: string[], rows: string[][]) {
  const lines = [headers.map(escapeCsvCell).join(",")]
  for (const row of rows) lines.push(row.map((c) => escapeCsvCell(c ?? "")).join(","))
  return lines.join("\n")
}

export function parseCsv(text: string) {
  const rows: string[][] = []
  let row: string[] = []
  let cell = ""
  let i = 0
  let inQuotes = false

  const pushCell = () => {
    row.push(cell)
    cell = ""
  }
  const pushRow = () => {
    rows.push(row)
    row = []
  }

  while (i < text.length) {
    const ch = text[i]
    if (inQuotes) {
      if (ch === '"') {
        const next = text[i + 1]
        if (next === '"') {
          cell += '"'
          i += 2
          continue
        }
        inQuotes = false
        i++
        continue
      }
      cell += ch
      i++
      continue
    }

    if (ch === '"') {
      inQuotes = true
      i++
      continue
    }

    if (ch === ",") {
      pushCell()
      i++
      continue
    }

    if (ch === "\n") {
      pushCell()
      pushRow()
      i++
      continue
    }

    if (ch === "\r") {
      const next = text[i + 1]
      if (next === "\n") {
        pushCell()
        pushRow()
        i += 2
        continue
      }
      pushCell()
      pushRow()
      i++
      continue
    }

    cell += ch
    i++
  }

  pushCell()
  if (row.length > 1 || row[0] !== "") pushRow()

  const headers = rows[0] ?? []
  const data = rows.slice(1)
  return { headers, rows: data }
}

