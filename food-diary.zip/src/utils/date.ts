export type WeekStart = "monday"

export function toISODate(d: Date) {
  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(2, "0")
  const day = String(d.getDate()).padStart(2, "0")
  return `${year}-${month}-${day}`
}

export function parseISODate(isoDate: string) {
  const [y, m, d] = isoDate.split("-").map((v) => Number(v))
  return new Date(y, m - 1, d)
}

export function addDays(d: Date, deltaDays: number) {
  const next = new Date(d)
  next.setDate(next.getDate() + deltaDays)
  return next
}

export function startOfWeek(d: Date, weekStart: WeekStart = "monday") {
  const day = d.getDay()
  const mondayOffset = (day + 6) % 7
  const start = addDays(new Date(d.getFullYear(), d.getMonth(), d.getDate()), -mondayOffset)
  if (weekStart !== "monday") return start
  return start
}

export function weekIdFromStartDate(weekStartDate: Date) {
  return `week_${toISODate(weekStartDate)}`
}

