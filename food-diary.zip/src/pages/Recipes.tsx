import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Download, FileSpreadsheet, MoreHorizontal, Plus, Upload } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCookbookStore } from "@/store/cookbookStore";
import { downloadTextFile } from "@/utils/storage";
import { parseCsv, toCsv } from "@/utils/csv";
import { createId } from "@/utils/id";

function toTagNames(recipeId: string, tags: Record<string, { id: string; name: string; color: string }>, recipeTags: { recipeId: string; tagId: string }[]) {
  const ids = recipeTags.filter((rt) => rt.recipeId === recipeId).map((rt) => rt.tagId);
  return ids.map((id) => tags[id]).filter(Boolean);
}

export default function Recipes() {
  const { data, actions } = useCookbookStore();
  const [q, setQ] = useState("");
  const [activeTagId, setActiveTagId] = useState<string | "">("");
  const [toast, setToast] = useState<string | null>(null);
  const [tagsExpanded, setTagsExpanded] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const csvRef = useRef<HTMLInputElement | null>(null);
  const toolsRef = useRef<HTMLDivElement | null>(null);

  const tagsSorted = useMemo(() => Object.values(data.tags).sort((a, b) => a.name.localeCompare(b.name)), [data.tags]);

  const recipeTagIdsByRecipeId = useMemo(() => {
    const map = new Map<string, string[]>();
    for (const rt of data.recipeTags) {
      const list = map.get(rt.recipeId) ?? [];
      list.push(rt.tagId);
      map.set(rt.recipeId, list);
    }
    return map;
  }, [data.recipeTags]);

  const tagCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const [recipeId, tagIds] of recipeTagIdsByRecipeId.entries()) {
      if (!data.recipes[recipeId]) continue;
      for (const tid of tagIds) counts[tid] = (counts[tid] ?? 0) + 1;
    }
    return counts;
  }, [data.recipes, recipeTagIdsByRecipeId]);

  const tagsForFilter = useMemo(() => {
    const withCount = tagsSorted.map((t) => ({ ...t, count: tagCounts[t.id] ?? 0 })).filter((t) => t.count > 0);
    withCount.sort((a, b) => (b.count !== a.count ? b.count - a.count : a.name.localeCompare(b.name)));
    return withCount;
  }, [tagCounts, tagsSorted]);

  const visibleTags = useMemo(() => (tagsExpanded ? tagsForFilter : tagsForFilter.slice(0, 8)), [tagsExpanded, tagsForFilter]);

  const list = useMemo(() => {
    const all = Object.values(data.recipes);
    const keyword = q.trim().toLowerCase();
    const filtered = all.filter((r) => {
      const matchesKeyword = !keyword || r.title.toLowerCase().includes(keyword);
      const tagIds = recipeTagIdsByRecipeId.get(r.id) ?? [];
      const matchesTag = !activeTagId || tagIds.includes(activeTagId);
      return matchesKeyword && matchesTag;
    });
    return filtered.sort((a, b) => (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
  }, [activeTagId, data.recipes, q, recipeTagIdsByRecipeId]);

  const onExport = () => {
    const text = actions.exportJsonText();
    const filename = `cookbook_${new Date().toISOString().slice(0, 10)}.json`;
    downloadTextFile(filename, text);
    setToast("已导出备份文件");
    window.setTimeout(() => setToast(null), 1600);
  };

  const onExportRecipesCsv = () => {
    const headers = ["id", "title", "tags", "servings", "totalMinutes", "difficulty", "ingredientLines", "stepLines", "notes", "lastCookedAt"];
    const rows = Object.values(data.recipes)
      .sort((a, b) => a.title.localeCompare(b.title))
      .map((r) => {
        const tagObjs = toTagNames(r.id, data.tags, data.recipeTags);
        const tags = tagObjs.map((t) => t.name).join(", ");
        return [
          r.id,
          r.title,
          tags,
          String(r.servings ?? ""),
          String(r.totalMinutes ?? ""),
          r.difficulty ?? "",
          (r.ingredientLines ?? []).join("\n"),
          (r.stepLines ?? []).join("\n"),
          r.notes ?? "",
          r.lastCookedAt ?? "",
        ];
      });
    const csv = "\ufeff" + toCsv(headers, rows);
    const filename = `recipes_${new Date().toISOString().slice(0, 10)}.csv`;
    downloadTextFile(filename, csv, "text/csv");
    setToast("已导出菜谱表格（CSV）");
    window.setTimeout(() => setToast(null), 1600);
  };

  const onPickImport = () => {
    fileRef.current?.click();
  };

  const onPickImportCsv = () => {
    csvRef.current?.click();
  };

  const onImportFile = async (file: File) => {
    const text = await file.text();
    const result = actions.importJsonText(text);
    if (result.ok) {
      setToast("已导入备份");
    } else {
      setToast((result as { ok: false; error: string }).error);
    }
    window.setTimeout(() => setToast(null), 2200);
  };

  const onImportRecipesCsv = async (file: File) => {
    const text = await file.text();
    const { headers, rows } = parseCsv(text.replace(/^\uFEFF/, ""));
    const idx = (name: string) => headers.findIndex((h) => h.trim() === name);
    const get = (r: string[], name: string) => {
      const i = idx(name);
      return i >= 0 ? (r[i] ?? "") : "";
    };

    const seen: string[] = [];
    for (const r of rows) {
      const title = get(r, "title").trim();
      if (!title) continue;
      const id = get(r, "id").trim();
      const recipeId = id ? id : createId("recipe");
      const servings = Number(get(r, "servings")) || 1;
      const totalMinutes = Number(get(r, "totalMinutes")) || 0;
      const difficulty = get(r, "difficulty").trim() || "简单";
      const ingredientLines = get(r, "ingredientLines")
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean);
      const stepLines = get(r, "stepLines")
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean);
      const notes = get(r, "notes");
      const lastCookedAt = get(r, "lastCookedAt").trim() || null;
      const tagNames = get(r, "tags")
        .split(/[,，;；]/g)
        .map((t) => t.trim())
        .filter(Boolean);

      actions.upsertRecipe(recipeId, { title, servings, totalMinutes, difficulty, ingredientLines, stepLines, notes, lastCookedAt });
      actions.setRecipeTagNames(recipeId, tagNames);
      seen.push(recipeId);
    }

    setToast(seen.length ? `已导入/更新 ${seen.length} 道菜谱` : "CSV 里没有可导入的菜谱");
    window.setTimeout(() => setToast(null), 2200);
  };

  useEffect(() => {
    if (!toolsOpen) return;
    const onDown = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node | null;
      if (!target) return;
      if (toolsRef.current && toolsRef.current.contains(target)) return;
      setToolsOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setToolsOpen(false);
    };
    window.addEventListener("mousedown", onDown);
    window.addEventListener("touchstart", onDown, { passive: true } as any);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", onDown);
      window.removeEventListener("touchstart", onDown as any);
      window.removeEventListener("keydown", onKey);
    };
  }, [toolsOpen]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <div className="text-sm font-medium">菜谱库</div>
          <div className="text-xs text-[color:var(--muted)]">标签可筛选；CSV 适合批量编辑；JSON 适合整库备份/换设备</div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div ref={toolsRef} className="relative">
            <button
              type="button"
              onClick={() => setToolsOpen((v) => !v)}
              className="inline-flex items-center gap-2 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm hover:bg-[color:var(--wash)]"
            >
              <MoreHorizontal className="h-4 w-4" />
              工具
            </button>
            {toolsOpen ? (
              <div className="absolute right-0 top-[44px] z-20 w-[min(90vw,20rem)] overflow-hidden rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] shadow-[var(--shadow-2)]">
                <button
                  type="button"
                  onClick={() => {
                    setToolsOpen(false);
                    onPickImport();
                  }}
                  className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-[color:var(--wash)]"
                >
                  <Upload className="h-4 w-4 text-[color:var(--muted)]" />
                  <div className="min-w-0">
                    <div className="font-medium">导入备份 (JSON)</div>
                    <div className="mt-0.5 text-xs text-[color:var(--muted)]">整库恢复/换设备</div>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setToolsOpen(false);
                    onExport();
                  }}
                  className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-[color:var(--wash)]"
                >
                  <Download className="h-4 w-4 text-[color:var(--muted)]" />
                  <div className="min-w-0">
                    <div className="font-medium">导出备份 (JSON)</div>
                    <div className="mt-0.5 text-xs text-[color:var(--muted)]">完整备份当前数据</div>
                  </div>
                </button>
                <div className="h-px bg-[color:var(--line)]" />
                <button
                  type="button"
                  onClick={() => {
                    setToolsOpen(false);
                    onPickImportCsv();
                  }}
                  className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-[color:var(--wash)]"
                >
                  <FileSpreadsheet className="h-4 w-4 text-[color:var(--muted)]" />
                  <div className="min-w-0">
                    <div className="font-medium">导入菜谱 (CSV)</div>
                    <div className="mt-0.5 text-xs text-[color:var(--muted)]">适合 Excel 批量编辑</div>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setToolsOpen(false);
                    onExportRecipesCsv();
                  }}
                  className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-[color:var(--wash)]"
                >
                  <FileSpreadsheet className="h-4 w-4 text-[color:var(--muted)]" />
                  <div className="min-w-0">
                    <div className="font-medium">导出菜谱 (CSV)</div>
                    <div className="mt-0.5 text-xs text-[color:var(--muted)]">导出成表格方便整理</div>
                  </div>
                </button>
              </div>
            ) : null}
          </div>
          <Link
            to="/recipes/new"
            className="inline-flex items-center gap-2 rounded-full bg-[color:var(--stamp)] px-3 py-1.5 text-sm font-medium text-[color:var(--paper)] hover:brightness-95"
          >
            <Plus className="h-4 w-4" />
            新建菜谱
          </Link>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="搜索菜名…"
          className="h-10 w-full rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
        />
      </div>

      {tagsForFilter.length ? (
        <div className="space-y-2">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            type="button"
            onClick={() => setActiveTagId("")}
            className={cn(
              "shrink-0 rounded-full px-3 py-1.5 text-sm transition",
              !activeTagId ? "bg-[color:var(--ink)] text-[color:var(--paper)]" : "bg-[color:var(--wash)] text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]",
            )}
          >
            全部
          </button>
          {visibleTags.map((t) => {
            const active = activeTagId === t.id;
            const count = t.count;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveTagId((prev) => (prev === t.id ? "" : t.id))}
                className={cn(
                  "shrink-0 rounded-full px-3 py-1.5 text-sm transition",
                  active ? "bg-[color:var(--stamp)] text-[color:var(--paper)]" : "bg-[color:var(--wash)] text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]",
                )}
              >
                {t.name}
                <span className={cn("ml-1 text-xs", active ? "opacity-90" : "opacity-70")}>({count})</span>
              </button>
            );
          })}
          {tagsForFilter.length > 8 ? (
            <button
              type="button"
              onClick={() => setTagsExpanded((v) => !v)}
              className="shrink-0 rounded-full bg-[color:var(--wash)] px-3 py-1.5 text-sm text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]"
            >
              {tagsExpanded ? "收起" : `更多(${tagsForFilter.length})`}
            </button>
          ) : null}
          </div>
        </div>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((r) => {
          const tagObjs = toTagNames(r.id, data.tags, data.recipeTags);
          return (
            <Link
              key={r.id}
              to={`/recipes/${r.id}`}
              className={cn(
                "group rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)] transition",
                "hover:-translate-y-0.5 hover:shadow-[var(--shadow-2)]",
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium">{r.title}</div>
                  <div className="mt-1 text-xs text-[color:var(--muted)]">
                    {r.lastCookedAt ? `最近做过：${r.lastCookedAt}` : "还没记录做过"}
                  </div>
                </div>
                <div className="rounded-full bg-[color:var(--wash)] px-2 py-0.5 text-xs text-[color:var(--muted)]">{r.totalMinutes} 分钟</div>
              </div>
              {tagObjs.length ? (
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {tagObjs.slice(0, 6).map((t) => (
                    <span key={t.id} className="rounded-full px-2 py-0.5 text-xs" style={{ background: `${t.color}22`, color: "var(--ink)" }}>
                      {t.name}
                    </span>
                  ))}
                </div>
              ) : null}
              {r.notes ? <div className="clamp-2 mt-3 text-xs text-[color:var(--muted)]">{r.notes}</div> : null}
            </Link>
          );
        })}
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="application/json"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          void onImportFile(file);
          e.currentTarget.value = "";
        }}
      />

      <input
        ref={csvRef}
        type="file"
        accept=".csv,text/csv"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          void onImportRecipesCsv(file);
          e.currentTarget.value = "";
        }}
      />

      <div
        className={cn(
          "fixed bottom-6 left-1/2 z-30 -translate-x-1/2 rounded-full px-4 py-2 text-sm shadow-[var(--shadow-2)] transition",
          toast ? "opacity-100" : "pointer-events-none opacity-0",
          "bg-[color:var(--ink)] text-[color:var(--paper)]",
        )}
        role="status"
      >
        {toast}
      </div>
    </div>
  );
}
