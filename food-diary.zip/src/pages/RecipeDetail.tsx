import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Copy, Save, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCookbookStore } from "@/store/cookbookStore";

function debounce<T extends (...args: any[]) => void>(fn: T, waitMs: number) {
  let t: number | undefined;
  return (...args: Parameters<T>) => {
    if (t) window.clearTimeout(t);
    t = window.setTimeout(() => fn(...args), waitMs);
  };
}

function splitLines(text: string) {
  return text
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
}

function parseTagNames(text: string) {
  return text
    .split(/[,，;；]/g)
    .map((t) => t.trim())
    .filter(Boolean);
}

export default function RecipeDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data, actions } = useCookbookStore();

  const isNew = id === "new";
  const recipe = id && !isNew ? data.recipes[id] : null;

  const tagNames = useMemo(() => {
    if (!id || isNew) return [];
    const tagIds = data.recipeTags.filter((rt) => rt.recipeId === id).map((rt) => rt.tagId);
    return tagIds.map((tid) => data.tags[tid]?.name).filter(Boolean) as string[];
  }, [data.recipeTags, data.tags, id, isNew]);

  const [title, setTitle] = useState(recipe?.title ?? "");
  const [ingredientsText, setIngredientsText] = useState(recipe ? recipe.ingredientLines.join("\n") : "");
  const [stepsText, setStepsText] = useState(recipe ? recipe.stepLines.join("\n") : "");
  const [notes, setNotes] = useState(recipe?.notes ?? "");
  const [servings, setServings] = useState(String(recipe?.servings ?? 2));
  const [totalMinutes, setTotalMinutes] = useState(String(recipe?.totalMinutes ?? 20));
  const [difficulty, setDifficulty] = useState(recipe?.difficulty ?? "简单");
  const [tagsText, setTagsText] = useState(tagNames.join(", "));
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (isNew) return;
    if (!recipe) return;
    setTitle(recipe.title);
    setIngredientsText(recipe.ingredientLines.join("\n"));
    setStepsText(recipe.stepLines.join("\n"));
    setNotes(recipe.notes);
    setServings(String(recipe.servings));
    setTotalMinutes(String(recipe.totalMinutes));
    setDifficulty(recipe.difficulty);
    setTagsText(tagNames.join(", "));
  }, [isNew, recipe, tagNames]);

  const draft = useMemo(() => {
    const tags = parseTagNames(tagsText);

    return {
      patch: {
        title: title.trim() || "未命名菜谱",
        ingredientLines: splitLines(ingredientsText),
        stepLines: splitLines(stepsText),
        notes,
        servings: Number(servings) || 1,
        totalMinutes: Number(totalMinutes) || 0,
        difficulty,
      },
      tags,
    };
  }, [difficulty, ingredientsText, notes, servings, stepsText, tagsText, title, totalMinutes]);

  const lastSavedRef = useRef<string>("");
  const debouncedSave = useMemo(
    () =>
      debounce((rid: string, patch: any, tags: string[]) => {
        actions.updateRecipe(rid, patch);
        actions.setRecipeTagNames(rid, tags);
      }, 500),
    [actions],
  );

  useEffect(() => {
    if (!id || isNew || !recipe) return;
    const payload = JSON.stringify({ id, ...draft.patch, tags: draft.tags });
    if (payload === lastSavedRef.current) return;
    lastSavedRef.current = payload;
    debouncedSave(id, draft.patch, draft.tags);
  }, [debouncedSave, draft, id, isNew, recipe]);

  const onSaveNew = () => {
    const rid = actions.createRecipe({
      ...draft.patch,
    });
    actions.setRecipeTagNames(rid, draft.tags);
    navigate(`/recipes/${rid}`);
  };

  const onSaveExisting = () => {
    if (!id || isNew) return;
    actions.updateRecipe(id, draft.patch);
    actions.setRecipeTagNames(id, draft.tags);
    setToast("已保存");
    window.setTimeout(() => setToast(null), 1400);
  };

  const onDelete = () => {
    if (!id || isNew) return;
    actions.deleteRecipe(id);
    navigate("/recipes");
  };

  const onDuplicate = () => {
    if (!recipe) return;
    const rid = actions.createRecipe({
      title: `${recipe.title}（复制）`,
      ingredientLines: recipe.ingredientLines,
      stepLines: recipe.stepLines,
      notes: recipe.notes,
      servings: recipe.servings,
      totalMinutes: recipe.totalMinutes,
      difficulty: recipe.difficulty,
      lastCookedAt: recipe.lastCookedAt,
    });
    actions.setRecipeTagNames(rid, tagNames);
    navigate(`/recipes/${rid}`);
  };

  if (!id) return null;

  if (!isNew && !recipe) {
    return (
      <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-6 shadow-[var(--shadow)]">
        <div className="text-sm font-medium">找不到这个菜谱</div>
        <div className="mt-2 text-sm text-[color:var(--muted)]">它可能被删除或导入时发生了冲突。</div>
        <Link to="/recipes" className="mt-4 inline-flex items-center gap-2 rounded-full bg-[color:var(--stamp)] px-3 py-1.5 text-sm font-medium text-[color:var(--paper)]">
          <ArrowLeft className="h-4 w-4" />
          回到菜谱库
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Link
            to="/recipes"
            className="inline-flex items-center gap-2 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm hover:bg-[color:var(--wash)]"
          >
            <ArrowLeft className="h-4 w-4" />
            返回
          </Link>
          <div className="space-y-0.5">
            <div className="text-sm font-medium">{isNew ? "新建菜谱" : "编辑菜谱"}</div>
            {!isNew && recipe?.lastCookedAt ? <div className="text-xs text-[color:var(--muted)]">最近做过：{recipe.lastCookedAt}</div> : null}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {!isNew ? (
            <button
              type="button"
              onClick={onDuplicate}
              className="inline-flex items-center gap-2 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm hover:bg-[color:var(--wash)]"
            >
              <Copy className="h-4 w-4" />
              复制
            </button>
          ) : null}

          {!isNew ? (
            <button
              type="button"
              onClick={onSaveExisting}
              className="inline-flex items-center gap-2 rounded-full bg-[color:var(--stamp)] px-3 py-1.5 text-sm font-medium text-[color:var(--paper)] hover:brightness-95"
            >
              <Save className="h-4 w-4" />
              保存
            </button>
          ) : null}

          {isNew ? (
            <button
              type="button"
              onClick={onSaveNew}
              className="inline-flex items-center gap-2 rounded-full bg-[color:var(--stamp)] px-3 py-1.5 text-sm font-medium text-[color:var(--paper)] hover:brightness-95"
            >
              <Save className="h-4 w-4" />
              保存
            </button>
          ) : (
            <button
              type="button"
              onClick={onDelete}
              className="inline-flex items-center gap-2 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm text-[color:var(--danger)] hover:bg-[color:var(--wash)]"
            >
              <Trash2 className="h-4 w-4" />
              删除
            </button>
          )}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-5 shadow-[var(--shadow)]">
          <div className="grid gap-3">
            <label className="space-y-1">
              <div className="text-xs text-[color:var(--muted)]">菜名</div>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="h-11 w-full rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
              />
            </label>

            <div className="grid gap-3 sm:grid-cols-3">
              <label className="space-y-1">
                <div className="text-xs text-[color:var(--muted)]">份量</div>
                <input
                  value={servings}
                  onChange={(e) => setServings(e.target.value)}
                  inputMode="numeric"
                  className="h-11 w-full rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
                />
              </label>
              <label className="space-y-1">
                <div className="text-xs text-[color:var(--muted)]">耗时（分钟）</div>
                <input
                  value={totalMinutes}
                  onChange={(e) => setTotalMinutes(e.target.value)}
                  inputMode="numeric"
                  className="h-11 w-full rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
                />
              </label>
              <label className="space-y-1">
                <div className="text-xs text-[color:var(--muted)]">难度</div>
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value)}
                  className="h-11 w-full rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
                >
                  {["简单", "一般", "有点难", "挑战"].map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <label className="space-y-1">
              <div className="text-xs text-[color:var(--muted)]">标签（用逗号分隔）</div>
              <input
                value={tagsText}
                onChange={(e) => setTagsText(e.target.value)}
                placeholder="家常, 快手, 下饭…"
                className="h-11 w-full rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
              />
            </label>

            <div className="grid gap-3 lg:grid-cols-2">
              <label className="space-y-1">
                <div className="text-xs text-[color:var(--muted)]">用料（每行一项）</div>
                <textarea
                  value={ingredientsText}
                  onChange={(e) => setIngredientsText(e.target.value)}
                  placeholder={"猪肉 200g\n蒜 2 瓣\n生抽 1 勺"}
                  className="min-h-52 w-full resize-none rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] p-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
                />
              </label>
              <label className="space-y-1">
                <div className="text-xs text-[color:var(--muted)]">步骤（每行一步）</div>
                <textarea
                  value={stepsText}
                  onChange={(e) => setStepsText(e.target.value)}
                  placeholder={"1）切配\n2）热锅下油\n3）翻炒调味"}
                  className="min-h-52 w-full resize-none rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] p-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
                />
              </label>
            </div>

            <label className="space-y-1">
              <div className="text-xs text-[color:var(--muted)]">备注</div>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="这道菜最关键的点是什么？下次想怎么改？"
                className="min-h-24 w-full resize-none rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] p-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
              />
            </label>
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-5 shadow-[var(--shadow)]">
            <div className="text-sm font-medium">快捷操作</div>
            <div className="mt-2 text-sm text-[color:var(--muted)]">
              {!isNew ? "编辑会自动保存到本地。" : "保存后会出现在菜谱库里。"}
            </div>
            <div className="mt-4 grid gap-2">
              <Link
                to="/week"
                className={cn(
                  "inline-flex h-10 items-center justify-center rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] text-sm hover:bg-[color:var(--wash)]",
                )}
              >
                去周计划页
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div
        className={cn(
          "fixed bottom-6 left-1/2 z-30 -translate-x-1/2 rounded-full px-4 py-2 text-sm shadow-[var(--shadow-2)] transition",
          toast ? "opacity-100" : "pointer-events-none opacity-0",
          "bg-[color:var(--ink)] text-[color:var(--paper)]",
        )}
        role="status"
      >
        {toast}
      </div>
    </div>
  );
}
