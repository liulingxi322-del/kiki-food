import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { ChevronLeft, ChevronRight, ListChecks, Plus, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { addDays, parseISODate, startOfWeek, toISODate, weekIdFromStartDate } from "@/utils/date";
import { useCookbookStore } from "@/store/cookbookStore";
import DishCard from "@/components/DishCard";
import WeekIngredients from "@/components/WeekIngredients";
import RecipePicker from "@/components/RecipePicker";

function weekdayLabel(idx: number) {
  return ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][idx] ?? "";
}

function formatMonthDay(isoDate: string) {
  const d = parseISODate(isoDate);
  return `${d.getMonth() + 1}/${d.getDate()}`;
}

export default function Week() {
  const [params, setParams] = useSearchParams();
  const { data, actions } = useCookbookStore();
  const [shoppingOpen, setShoppingOpen] = useState(false);
  const [weekInfoOpen, setWeekInfoOpen] = useState(false);

  const weekStartIso = useMemo(() => {
    const fromUrl = params.get("start");
    if (fromUrl) return fromUrl;
    return toISODate(startOfWeek(new Date()));
  }, [params]);

  const weekStartDate = useMemo(() => parseISODate(weekStartIso), [weekStartIso]);
  const weekId = useMemo(() => weekIdFromStartDate(weekStartDate), [weekStartDate]);

  useEffect(() => {
    actions.ensureWeekByDate(weekStartIso);
  }, [actions, weekStartIso]);

  const dates = useMemo(() => Array.from({ length: 7 }, (_, i) => toISODate(addDays(weekStartDate, i))), [weekStartDate]);
  const todayIso = useMemo(() => toISODate(new Date()), []);
  const isTodayInWeek = useMemo(() => dates.includes(todayIso), [dates, todayIso]);

  const dayIso = useMemo(() => {
    const fromUrl = params.get("day");
    if (fromUrl && dates.includes(fromUrl)) return fromUrl;
    return isTodayInWeek ? todayIso : dates[0];
  }, [dates, isTodayInWeek, params, todayIso]);

  useEffect(() => {
    const fromUrl = params.get("day");
    if (!fromUrl || !dates.includes(fromUrl)) setParams({ start: weekStartIso, day: dayIso }, { replace: true });
  }, [dates, dayIso, params, setParams, weekStartIso]);

  const dishesByDay = useMemo(() => {
    const map = new Map<string, string[]>();
    for (const dish of Object.values(data.dishes)) {
      const list = map.get(dish.dayLogId) ?? [];
      list.push(dish.id);
      map.set(dish.dayLogId, list);
    }
    for (const list of map.values()) {
      list.sort((a, b) => {
        const da = data.dishes[a]?.createdAt ?? "";
        const db = data.dishes[b]?.createdAt ?? "";
        return da.localeCompare(db);
      });
    }
    return map;
  }, [data.dishes]);

  const week = data.weeks[weekId];
  const weekDishCount = useMemo(() => {
    const dayIds = new Set(dates.map((d) => `day_${weekId}_${d}`));
    let count = 0;
    for (const dish of Object.values(data.dishes)) if (dayIds.has(dish.dayLogId)) count++;
    return count;
  }, [data.dishes, dates, weekId]);

  const goWeek = (deltaWeeks: number) => {
    const nextStart = toISODate(addDays(weekStartDate, deltaWeeks * 7));
    const nextDates = Array.from({ length: 7 }, (_, i) => toISODate(addDays(parseISODate(nextStart), i)));
    const nextDay = nextDates.includes(todayIso) ? todayIso : nextDates[0];
    setParams({ start: nextStart, day: nextDay });
  };

  return (
    <>
      <div className="space-y-4 lg:hidden">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => goWeek(-1)}
              className="inline-flex items-center gap-1 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm hover:bg-[color:var(--wash)]"
            >
              <ChevronLeft className="h-4 w-4" />
              上周
            </button>
            <button
              type="button"
              onClick={() => goWeek(1)}
              className="inline-flex items-center gap-1 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm hover:bg-[color:var(--wash)]"
            >
              下周
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
          <button
            type="button"
            onClick={() => setShoppingOpen(true)}
            className="inline-flex items-center gap-2 rounded-full bg-[color:var(--stamp)] px-3 py-1.5 text-sm font-medium text-[color:var(--paper)]"
          >
            <ListChecks className="h-4 w-4" />
            备菜清单
          </button>
        </div>

        <div className="rounded-full bg-[color:var(--wash)] px-3 py-1.5 text-sm text-[color:var(--muted)]">
          {weekStartIso} ～ {toISODate(addDays(weekStartDate, 6))}
        </div>

        <div className="sticky top-[56px] z-10 -mx-4 border-b border-[color:var(--line)] bg-[color:var(--paper)]/95 px-4 py-2 backdrop-blur">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {dates.map((d, idx) => {
              const active = d === dayIso;
              const isToday = d === todayIso;
              return (
                <button
                  key={d}
                  type="button"
                  onClick={() => setParams({ start: weekStartIso, day: d })}
                  className={cn(
                    "shrink-0 rounded-full px-3 py-1.5 text-sm transition",
                    active ? "bg-[color:var(--ink)] text-[color:var(--paper)]" : "bg-[color:var(--wash)] text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]",
                  )}
                >
                  {weekdayLabel(idx)}
                  <span className="ml-1 text-xs opacity-80">{formatMonthDay(d)}</span>
                  {isToday ? <span className="ml-1 text-xs opacity-90">今</span> : null}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-3">
          <DayCard dateIso={dayIso} label={weekdayLabel(dates.indexOf(dayIso))} dishIds={dishesByDay.get(`day_${weekId}_${dayIso}`) ?? []} weekId={weekId} />

          <div className="flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setWeekInfoOpen((v) => !v)}
              className="inline-flex items-center gap-2 rounded-full bg-[color:var(--wash)] px-3 py-1.5 text-sm text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]"
            >
              本周回顾与统计
            </button>

            <button
              type="button"
              onClick={() => {
                const idx = dates.indexOf(dayIso);
                if (idx < 0) return;
                if (idx < 6) setParams({ start: weekStartIso, day: dates[idx + 1] });
                else goWeek(1);
              }}
              className="inline-flex items-center gap-2 rounded-full bg-[color:var(--wash)] px-3 py-1.5 text-sm text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]"
            >
              下一天
            </button>
          </div>

          {weekInfoOpen ? (
            <div className="space-y-3">
              <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)]">
                <div className="mb-2 flex items-center justify-between">
                  <div className="text-sm font-medium">本周回顾</div>
                  <div className="text-xs text-[color:var(--muted)]">{week ? `${weekDishCount} 条记录` : ""}</div>
                </div>
                <textarea
                  value={week?.summary ?? ""}
                  onChange={(e) => actions.setWeekSummary(weekId, e.target.value)}
                  placeholder="这周做饭有什么心得？下次想怎么改？"
                  className="min-h-28 w-full resize-none rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] p-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
                />
              </div>

              <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)]">
                <div className="mb-3 text-sm font-medium">本周做过的菜</div>
                <WeekStats weekId={weekId} dates={dates} />
              </div>
            </div>
          ) : null}
        </div>
      </div>

      <div className="hidden gap-6 lg:grid lg:grid-cols-[1fr_340px]">
        <section className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => goWeek(-1)}
                className="inline-flex items-center gap-1 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm hover:bg-[color:var(--wash)]"
              >
                <ChevronLeft className="h-4 w-4" />
                上周
              </button>
              <button
                type="button"
                onClick={() => goWeek(1)}
                className="inline-flex items-center gap-1 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm hover:bg-[color:var(--wash)]"
              >
                下周
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
            <div className="rounded-full bg-[color:var(--wash)] px-3 py-1.5 text-sm text-[color:var(--muted)]">
              {weekStartIso} ～ {toISODate(addDays(weekStartDate, 6))}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {dates.map((dateIso, idx) => (
              <DayCard
                key={dateIso}
                dateIso={dateIso}
                label={weekdayLabel(idx)}
                dishIds={dishesByDay.get(`day_${weekId}_${dateIso}`) ?? []}
                weekId={weekId}
              />
            ))}
          </div>
        </section>

        <aside className="space-y-4">
          <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)]">
            <div className="mb-2 flex items-center justify-between">
              <div className="text-sm font-medium">本周回顾</div>
              <div className="text-xs text-[color:var(--muted)]">{week ? `${weekDishCount} 条记录` : ""}</div>
            </div>
            <textarea
              value={week?.summary ?? ""}
              onChange={(e) => actions.setWeekSummary(weekId, e.target.value)}
              placeholder="这周做饭有什么心得？下次想怎么改？"
              className="min-h-28 w-full resize-none rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] p-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
            />
          </div>

          <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)]">
            <div className="mb-3 text-sm font-medium">本周备菜清单</div>
            <WeekIngredients weekId={weekId} dates={dates} />
          </div>

          <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)]">
            <div className="mb-3 text-sm font-medium">本周做过的菜</div>
            <WeekStats weekId={weekId} dates={dates} />
          </div>
        </aside>
      </div>

      {shoppingOpen ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button type="button" onClick={() => setShoppingOpen(false)} className="absolute inset-0 bg-black/35" aria-label="关闭" />
          <div className="absolute inset-x-0 bottom-0 max-h-[85dvh] overflow-auto rounded-t-3xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow-2)]">
            <div className="mb-3 flex items-center justify-between">
              <div className="text-sm font-medium">本周备菜清单</div>
              <button
                type="button"
                onClick={() => setShoppingOpen(false)}
                className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-[color:var(--wash)] hover:bg-[color:var(--wash-2)]"
                aria-label="关闭"
              >
                <X className="h-4 w-4 text-[color:var(--muted)]" />
              </button>
            </div>
            <WeekIngredients weekId={weekId} dates={dates} mode="shopping" />
          </div>
        </div>
      ) : null}
    </>
  );
}

function DayCard({ dateIso, label, dishIds, weekId }: { dateIso: string; label: string; dishIds: string[]; weekId: string }) {
  const { data, actions } = useCookbookStore();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [recipeId, setRecipeId] = useState<string | "">("");

  const recipeItems = useMemo(() => {
    const recipes = Object.values(data.recipes).sort((a, b) => a.title.localeCompare(b.title));
    const tagNameById = (tagId: string) => data.tags[tagId]?.name ?? "";
    const tagMap = new Map<string, string[]>();
    for (const rt of data.recipeTags) {
      const list = tagMap.get(rt.recipeId) ?? [];
      const name = tagNameById(rt.tagId);
      if (name) list.push(name);
      tagMap.set(rt.recipeId, list);
    }
    return recipes.map((r) => ({ id: r.id, title: r.title, tags: tagMap.get(r.id) ?? [] }));
  }, [data.recipes, data.recipeTags, data.tags]);

  const onAdd = () => {
    const selectedRecipe = recipeId ? data.recipes[recipeId] : null;
    const finalTitle = (title || selectedRecipe?.title || "").trim();
    if (!finalTitle) return;
    const id = actions.addDish(dateIso, { title: finalTitle, recipeId: recipeId || null });
    if (recipeId) actions.markRecipeCooked(recipeId, dateIso);
    setTitle("");
    setRecipeId("");
    setOpen(false);
    return id;
  };

  return (
    <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)]">
      <div className="mb-3 flex items-center justify-between">
        <div className="space-y-0.5">
          <div className="text-sm font-medium">{label}</div>
          <div className="text-xs text-[color:var(--muted)]">{formatMonthDay(dateIso)}</div>
        </div>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className={cn(
            "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm transition",
            open ? "bg-[color:var(--stamp)] text-[color:var(--paper)]" : "bg-[color:var(--wash)] hover:bg-[color:var(--wash-2)]",
          )}
        >
          <Plus className="h-4 w-4" />
          添加
        </button>
      </div>

      {open ? (
        <div className="mb-3 space-y-2">
          <div className="grid gap-2">
            <RecipePicker items={recipeItems} value={recipeId} onChange={(v) => setRecipeId(v)} placeholder="搜索并选择菜谱（可选）" />
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="或者直接输入菜名（覆盖菜谱名）"
              className="h-10 w-full rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
            />
          </div>
          <button
            type="button"
            onClick={onAdd}
            className="inline-flex h-10 w-full items-center justify-center rounded-xl bg-[color:var(--stamp)] text-sm font-medium text-[color:var(--paper)] hover:brightness-95"
          >
            写入今天
          </button>
        </div>
      ) : null}

      <div className="space-y-2">
        {dishIds.length === 0 ? <div className="text-xs text-[color:var(--muted)]">今天还没记录</div> : null}
          {dishIds.map((id) => (
            <DishCard key={id} dishId={id} weekId={weekId} />
          ))}
      </div>
    </div>
  );
}

function WeekStats({ weekId, dates }: { weekId: string; dates: string[] }) {
  const { data } = useCookbookStore();

  const items = useMemo(() => {
    const counts = new Map<string, number>();
    for (const date of dates) {
      const dayId = `day_${weekId}_${date}`;
      for (const dish of Object.values(data.dishes)) {
        if (dish.dayLogId !== dayId) continue;
        counts.set(dish.title, (counts.get(dish.title) ?? 0) + 1);
      }
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8);
  }, [data.dishes, dates, weekId]);

  if (items.length === 0) return <div className="text-xs text-[color:var(--muted)]">本周还没有记录</div>;

  return (
    <div className="space-y-2">
      {items.map(([title, count]) => (
        <div key={title} className="flex items-center justify-between gap-4 rounded-xl bg-[color:var(--wash)] px-3 py-2">
          <div className="min-w-0 truncate text-sm">{title}</div>
          <div className="shrink-0 rounded-full bg-[color:var(--paper)] px-2 py-0.5 text-xs text-[color:var(--muted)]">× {count}</div>
        </div>
      ))}
    </div>
  );
}
