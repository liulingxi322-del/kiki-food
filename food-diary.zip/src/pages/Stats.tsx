import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { toISODate } from "@/utils/date";
import { useCookbookStore } from "@/store/cookbookStore";

function isoFromDayLogId(dayLogId: string) {
  const tail = dayLogId.slice(-10);
  return /^\d{4}-\d{2}-\d{2}$/.test(tail) ? tail : null;
}

function ymKey(dateIso: string) {
  return dateIso.slice(0, 7);
}

function yKey(dateIso: string) {
  return dateIso.slice(0, 4);
}

function startOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

function addMonths(d: Date, delta: number) {
  return new Date(d.getFullYear(), d.getMonth() + delta, 1);
}

function weekdayMondayIndex(d: Date) {
  return (d.getDay() + 6) % 7;
}

export default function Stats() {
  const { data } = useCookbookStore();
  const todayIso = useMemo(() => toISODate(new Date()), []);

  const [monthCursor, setMonthCursor] = useState(() => startOfMonth(new Date()));
  const monthKey = useMemo(() => `${monthCursor.getFullYear()}-${String(monthCursor.getMonth() + 1).padStart(2, "0")}`, [monthCursor]);
  const yearKey = useMemo(() => String(monthCursor.getFullYear()), [monthCursor]);
  const [selectedDateIso, setSelectedDateIso] = useState<string | null>(todayIso);
  const [mobileTab, setMobileTab] = useState<"calendar" | "rank">("calendar");

  const dishEvents = useMemo(() => {
    const events: { dateIso: string; title: string; recipeId: string | null }[] = [];
    for (const dish of Object.values(data.dishes)) {
      const dateIso = isoFromDayLogId(dish.dayLogId);
      if (!dateIso) continue;
      const recipe = dish.recipeId ? data.recipes[dish.recipeId] : null;
      events.push({ dateIso, title: recipe?.title ?? dish.title, recipeId: dish.recipeId ?? null });
    }
    return events;
  }, [data.dishes, data.recipes]);

  const monthCounts = useMemo(() => {
    const map = new Map<string, number>();
    for (const e of dishEvents) {
      if (ymKey(e.dateIso) !== monthKey) continue;
      map.set(e.dateIso, (map.get(e.dateIso) ?? 0) + 1);
    }
    return map;
  }, [dishEvents, monthKey]);

  const monthPopular = useMemo(() => {
    const counts = new Map<string, number>();
    for (const e of dishEvents) {
      if (ymKey(e.dateIso) !== monthKey) continue;
      counts.set(e.title, (counts.get(e.title) ?? 0) + 1);
    }
    return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5);
  }, [dishEvents, monthKey]);

  const yearPopular = useMemo(() => {
    const counts = new Map<string, number>();
    for (const e of dishEvents) {
      if (yKey(e.dateIso) !== yearKey) continue;
      counts.set(e.title, (counts.get(e.title) ?? 0) + 1);
    }
    return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10);
  }, [dishEvents, yearKey]);

  const calendarCells = useMemo(() => {
    const start = startOfMonth(monthCursor);
    const offset = weekdayMondayIndex(start);
    const firstCell = new Date(start);
    firstCell.setDate(firstCell.getDate() - offset);
    return Array.from({ length: 42 }, (_, i) => {
      const d = new Date(firstCell);
      d.setDate(firstCell.getDate() + i);
      const iso = toISODate(d);
      return { iso, d };
    });
  }, [monthCursor]);

  const selectedEvents = useMemo(() => {
    if (!selectedDateIso) return [];
    return dishEvents.filter((e) => e.dateIso === selectedDateIso);
  }, [dishEvents, selectedDateIso]);

  const CalendarPanel = (
    <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)]">
      <div className="mb-3 flex items-center justify-between">
        <div className="text-sm font-medium">{monthKey} 菜品日历</div>
        <div className="text-xs text-[color:var(--muted)]">点日期查看当天</div>
      </div>

      <div className="grid grid-cols-7 gap-2 text-xs text-[color:var(--muted)]">
        {["一", "二", "三", "四", "五", "六", "日"].map((w) => (
          <div key={w} className="px-1 text-center">
            周{w}
          </div>
        ))}
      </div>

      <div className="mt-2 grid grid-cols-7 gap-2">
        {calendarCells.map(({ iso, d }) => {
          const inMonth = d.getMonth() === monthCursor.getMonth();
          const count = monthCounts.get(iso) ?? 0;
          const active = selectedDateIso === iso;
          const isToday = iso === todayIso;
          return (
            <button
              key={iso}
              type="button"
              onClick={() => setSelectedDateIso(iso)}
              className={cn(
                "rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-1.5 py-2 text-left transition sm:px-2 sm:py-2",
                !inMonth ? "opacity-40" : "",
                active ? "bg-[color:var(--wash-2)]" : "hover:bg-[color:var(--wash)]",
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <div className={cn("text-sm font-medium", isToday ? "text-[color:var(--stamp)]" : "")}>{d.getDate()}</div>
                {count ? <div className="rounded-full bg-[color:var(--wash)] px-2 py-0.5 text-xs text-[color:var(--muted)]">×{count}</div> : null}
              </div>
            </button>
          );
        })}
      </div>

      <div className="mt-4 rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4">
        <div className="mb-2 flex items-center justify-between">
          <div className="text-sm font-medium">{selectedDateIso ?? ""}</div>
          <div className="text-xs text-[color:var(--muted)]">{selectedEvents.length ? `${selectedEvents.length} 道菜` : "无记录"}</div>
        </div>
        <div className="space-y-2">
          {selectedEvents.length === 0 ? <div className="text-sm text-[color:var(--muted)]">这天还没有记录</div> : null}
          {selectedEvents.map((e, idx) => (
            <div key={`${e.dateIso}_${idx}`} className="rounded-xl bg-[color:var(--wash)] px-3 py-2 text-sm">
              {e.title}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const RankPanel = (
    <div className="space-y-4">
      <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)]">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-sm font-medium">{monthKey} 热门菜</div>
            <div className="mt-1 text-xs text-[color:var(--muted)]">仅展示前 5 个高频</div>
          </div>
        </div>
        <RankList items={monthPopular} emptyText="本月还没有记录" />
      </div>

      <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-4 shadow-[var(--shadow)]">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-sm font-medium">{yearKey} 年度热门菜</div>
            <div className="mt-1 text-xs text-[color:var(--muted)]">展示前 10，用于年末回顾</div>
          </div>
        </div>
        <RankList items={yearPopular} emptyText="今年还没有记录" />
      </div>
    </div>
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-1">
          <div className="text-sm font-medium">统计</div>
          <div className="text-xs text-[color:var(--muted)]">月度/年度热门菜 + 菜品日历</div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setMonthCursor((d) => addMonths(d, -1))}
            className="inline-flex items-center gap-1 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm hover:bg-[color:var(--wash)]"
          >
            <ChevronLeft className="h-4 w-4" />
            上月
          </button>
          <button
            type="button"
            onClick={() => setMonthCursor((d) => addMonths(d, 1))}
            className="inline-flex items-center gap-1 rounded-full border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-1.5 text-sm hover:bg-[color:var(--wash)]"
          >
            下月
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="sm:hidden">
        <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] p-1 shadow-[var(--shadow)]">
          <div className="grid grid-cols-2 gap-1">
            <button
              type="button"
              onClick={() => setMobileTab("calendar")}
              className={cn(
                "rounded-xl px-3 py-2 text-sm transition",
                mobileTab === "calendar" ? "bg-[color:var(--wash-2)] text-[color:var(--ink)]" : "text-[color:var(--muted)] hover:bg-[color:var(--wash)]",
              )}
            >
              日历
            </button>
            <button
              type="button"
              onClick={() => setMobileTab("rank")}
              className={cn(
                "rounded-xl px-3 py-2 text-sm transition",
                mobileTab === "rank" ? "bg-[color:var(--wash-2)] text-[color:var(--ink)]" : "text-[color:var(--muted)] hover:bg-[color:var(--wash)]",
              )}
            >
              排行
            </button>
          </div>
        </div>
        <div className="mt-4">{mobileTab === "calendar" ? CalendarPanel : RankPanel}</div>
      </div>

      <div className="hidden gap-4 sm:grid lg:grid-cols-[1fr_340px]">
        {CalendarPanel}
        {RankPanel}
      </div>
    </div>
  );
}

function RankList({ items, emptyText }: { items: Array<[string, number]>; emptyText: string }) {
  if (!items.length) return <div className="text-sm text-[color:var(--muted)]">{emptyText}</div>;
  return (
    <div className="space-y-2">
      {items.map(([title, count], idx) => (
        <div key={title} className="flex items-center justify-between gap-4 rounded-xl bg-[color:var(--wash)] px-3 py-2">
          <div className="min-w-0 truncate text-sm">
            <span className="mr-2 text-xs text-[color:var(--muted)]">{idx + 1}</span>
            {title}
          </div>
          <div className="shrink-0 rounded-full bg-[color:var(--paper)] px-2 py-0.5 text-xs text-[color:var(--muted)]">× {count}</div>
        </div>
      ))}
    </div>
  );
}
