import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { useCookbookStore } from "@/store/cookbookStore";

function normalizeIngredient(line: string) {
  return line.trim();
}

export default function WeekIngredients({ weekId, dates, mode }: { weekId: string; dates: string[]; mode?: "shopping" | "default" }) {
  const { data, actions } = useCookbookStore();
  const week = data.weeks[weekId];
  const [onlyMissing, setOnlyMissing] = useState(mode === "shopping");

  const items = useMemo(() => {
    const counts = new Map<string, number>();
    const dayIds = new Set(dates.map((d) => `day_${weekId}_${d}`));
    for (const dish of Object.values(data.dishes)) {
      if (!dayIds.has(dish.dayLogId)) continue;
      for (const line of dish.ingredientLines ?? []) {
        const key = normalizeIngredient(line);
        if (!key) continue;
        counts.set(key, (counts.get(key) ?? 0) + 1);
      }
    }
    return Array.from(counts.entries()).sort((a, b) => (b[1] !== a[1] ? b[1] - a[1] : a[0].localeCompare(b[0])));
  }, [data.dishes, dates, weekId]);

  if (!week) return null;

  const haveMap = week.ingredientHave ?? {};
  const prepared = items.filter(([line]) => !!haveMap[line]);
  const missing = items.filter(([line]) => !haveMap[line]);
  const displayItems = onlyMissing ? missing : [...missing, ...prepared];

  return (
    <div className="space-y-2">
      {items.length === 0 ? <div className="text-xs text-[color:var(--muted)]">本周还没从菜品里提取到食材</div> : null}

      {items.length ? (
        <div className="flex items-center justify-between gap-3">
          <div className="text-xs text-[color:var(--muted)]">
            未备齐 {missing.length} / 共 {items.length}
          </div>
          <button
            type="button"
            onClick={() => setOnlyMissing((v) => !v)}
            className={cn(
              "inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs transition",
              onlyMissing ? "bg-[color:var(--stamp)] text-[color:var(--paper)]" : "bg-[color:var(--wash)] text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]",
            )}
          >
            {onlyMissing ? "只看未备齐" : "显示全部"}
          </button>
        </div>
      ) : null}

      {displayItems.slice(0, 60).map(([line, count]) => {
        const checked = !!haveMap[line];
        return (
          <label
            key={line}
            className={cn(
              "flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 py-2 text-sm",
              checked ? "opacity-80" : "",
            )}
          >
            <div className="min-w-0 flex-1 truncate">
              <span className={cn(checked ? "line-through text-[color:var(--muted)]" : "")}>{line}</span>
              <span className="ml-2 rounded-full bg-[color:var(--wash)] px-2 py-0.5 text-xs text-[color:var(--muted)]">× {count}</span>
            </div>
            <input
              type="checkbox"
              checked={checked}
              onChange={(e) => actions.setWeekIngredientHave(weekId, line, e.target.checked)}
              className="h-4 w-4 accent-[color:var(--stamp)]"
            />
          </label>
        );
      })}
    </div>
  );
}
