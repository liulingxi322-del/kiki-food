import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ChevronDown, ChevronUp, RefreshCcw, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCookbookStore } from "@/store/cookbookStore";

function normalizeIngredient(line: string) {
  return line.trim();
}

export default function DishCard({ dishId, weekId }: { dishId: string; weekId: string }) {
  const { data, actions } = useCookbookStore();
  const dish = data.dishes[dishId];
  const week = data.weeks[weekId];
  const recipe = dish?.recipeId ? data.recipes[dish.recipeId] : null;
  const [open, setOpen] = useState(false);

  const ingredientLines = dish?.ingredientLines ?? [];
  const normalized = useMemo(() => ingredientLines.map(normalizeIngredient).filter(Boolean), [ingredientLines]);
  const uniqueLines = useMemo(() => Array.from(new Set(normalized)), [normalized]);

  const checkedCount = useMemo(() => {
    const map = week?.ingredientHave ?? {};
    return uniqueLines.reduce((acc, line) => acc + (map[line] ? 1 : 0), 0);
  }, [uniqueLines, week?.ingredientHave]);

  if (!dish) return null;

  return (
    <div className="rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] p-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="truncate text-sm font-medium">{dish.title}</div>
          <div className="mt-1 flex items-center gap-2">
            {recipe ? (
              <Link
                to={`/recipes/${recipe.id}`}
                className="rounded-full bg-[color:var(--wash)] px-2 py-0.5 text-xs text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]"
              >
                去菜谱
              </Link>
            ) : (
              <div className="rounded-full bg-[color:var(--wash)] px-2 py-0.5 text-xs text-[color:var(--muted)]">临时菜</div>
            )}

            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className="inline-flex items-center gap-1 rounded-full bg-[color:var(--wash)] px-2 py-0.5 text-xs text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]"
            >
              食材 {uniqueLines.length ? `${checkedCount}/${uniqueLines.length}` : ""}
              {open ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={() => actions.removeDish(dishId)}
          className="inline-flex h-8 w-8 items-center justify-center rounded-full hover:bg-[color:var(--wash)]"
          aria-label="删除"
        >
          <Trash2 className="h-4 w-4 text-[color:var(--muted)]" />
        </button>
      </div>

      <textarea
        value={dish.tweakNote}
        onChange={(e) => actions.updateDish(dishId, { tweakNote: e.target.value })}
        placeholder="做法小改动 / 今天的笔记"
        className="mt-2 min-h-16 w-full resize-none rounded-lg border border-[color:var(--line)] bg-[color:var(--paper)] p-2 text-xs outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
      />

      {open ? (
        <div className="mt-3 space-y-2">
          <div className="flex items-center justify-between gap-3">
            <div className="text-xs text-[color:var(--muted)]">食材（每行一项）</div>
            {recipe ? (
              <button
                type="button"
                onClick={() => actions.updateDish(dishId, { ingredientLines: recipe.ingredientLines })}
                className="inline-flex items-center gap-2 rounded-full bg-[color:var(--wash)] px-2 py-0.5 text-xs text-[color:var(--muted)] hover:bg-[color:var(--wash-2)]"
              >
                <RefreshCcw className="h-3.5 w-3.5" />
                同步菜谱食材
              </button>
            ) : null}
          </div>

          <textarea
            value={ingredientLines.join("\n")}
            onChange={(e) =>
              actions.updateDish(dishId, {
                ingredientLines: e.target.value
                  .split("\n")
                  .map((s) => s.trim())
                  .filter(Boolean),
              })
            }
            placeholder={"猪肉 200g\n蒜 2 瓣\n生抽 1 勺"}
            className="min-h-20 w-full resize-none rounded-lg border border-[color:var(--line)] bg-[color:var(--paper)] p-2 text-xs outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
          />

          <div className="space-y-1.5">
            {uniqueLines.length === 0 ? <div className="text-xs text-[color:var(--muted)]">还没填食材</div> : null}
            {uniqueLines.map((line) => {
              const checked = !!(week?.ingredientHave ?? {})[line];
              return (
                <label
                  key={line}
                  className={cn(
                    "flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-[color:var(--line)] bg-[color:var(--paper)] px-2.5 py-2 text-xs",
                    checked ? "opacity-80" : "",
                  )}
                >
                  <div className={cn("min-w-0 flex-1 truncate", checked ? "line-through text-[color:var(--muted)]" : "")}>{line}</div>
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={(e) => actions.setWeekIngredientHave(weekId, line, e.target.checked)}
                    className="h-4 w-4 accent-[color:var(--stamp)]"
                  />
                </label>
              );
            })}
          </div>
        </div>
      ) : null}
    </div>
  );
}

