import { NavLink } from "react-router-dom";
import { BarChart3, BookOpen, CalendarDays } from "lucide-react";
import { cn } from "@/lib/utils";

function NavItem({
  to,
  label,
  icon,
}: {
  to: string;
  label: string;
  icon: React.ReactNode;
}) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm transition",
          isActive ? "bg-[color:var(--stamp)] text-[color:var(--paper)]" : "hover:bg-[color:var(--wash)]",
        )
      }
    >
      {icon}
      {label}
    </NavLink>
  );
}

export default function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh bg-[var(--paper)] text-[var(--ink)]">
      <header className="sticky top-0 z-20 border-b border-[color:var(--line)] bg-[var(--paper)]/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-baseline gap-3">
            <div className="font-display text-lg font-semibold tracking-wide">神厨小福Ki的美食日记</div>
            <div className="hidden text-sm text-[color:var(--muted)] sm:block">一周备菜清单 · 每日做饭 · 月度热门</div>
          </div>
          <nav className="hidden items-center gap-2 sm:flex">
            <NavItem to="/week" label="周计划" icon={<CalendarDays className="h-4 w-4" />} />
            <NavItem to="/recipes" label="菜谱库" icon={<BookOpen className="h-4 w-4" />} />
            <NavItem to="/stats" label="统计" icon={<BarChart3 className="h-4 w-4" />} />
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-5 pb-24 sm:pb-6">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-[color:var(--line)] bg-[var(--paper)]/92 backdrop-blur sm:hidden">
        <div className="mx-auto flex max-w-6xl items-center justify-around px-3 py-2">
          <BottomTab to="/week" label="周计划" icon={<CalendarDays className="h-5 w-5" />} />
          <BottomTab to="/recipes" label="菜谱库" icon={<BookOpen className="h-5 w-5" />} />
          <BottomTab to="/stats" label="统计" icon={<BarChart3 className="h-5 w-5" />} />
        </div>
      </nav>
    </div>
  );
}

function BottomTab({
  to,
  label,
  icon,
}: {
  to: string;
  label: string;
  icon: React.ReactNode;
}) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          "flex w-full max-w-[140px] flex-col items-center justify-center gap-1 rounded-2xl px-3 py-2 text-xs transition",
          isActive ? "bg-[color:var(--wash-2)] text-[color:var(--ink)]" : "text-[color:var(--muted)] hover:bg-[color:var(--wash)]",
        )
      }
    >
      {icon}
      <div className="font-medium">{label}</div>
    </NavLink>
  );
}
