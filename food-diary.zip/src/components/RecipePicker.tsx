import { useMemo, useState } from "react";
import { Check, ChevronDown, X } from "lucide-react";
import { cn } from "@/lib/utils";

export type RecipePickerItem = {
  id: string;
  title: string;
  tags: string[];
};

function normalize(s: string) {
  return s.trim().toLowerCase();
}

export default function RecipePicker({
  items,
  value,
  onChange,
  placeholder,
}: {
  items: RecipePickerItem[];
  value: string | "";
  onChange: (next: string | "") => void;
  placeholder?: string;
}) {
  const selected = useMemo(() => (value ? items.find((i) => i.id === value) ?? null : null), [items, value]);
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const keyword = normalize(q);
    if (!keyword) return items.slice(0, 10);
    return items
      .filter((i) => normalize(i.title).includes(keyword) || i.tags.some((t) => normalize(t).includes(keyword)))
      .slice(0, 10);
  }, [items, q]);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex h-10 w-full items-center justify-between rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 text-left text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
      >
        <div className="min-w-0 flex-1 truncate">{selected ? selected.title : placeholder ?? "搜索并选择菜谱（可选）"}</div>
        <div className="flex items-center gap-1">
          {selected ? (
            <span
              role="button"
              tabIndex={0}
              onClick={(e) => {
                e.stopPropagation();
                onChange("");
                setQ("");
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  e.stopPropagation();
                  onChange("");
                  setQ("");
                }
              }}
              className="inline-flex h-7 w-7 items-center justify-center rounded-full hover:bg-[color:var(--wash)]"
              aria-label="清除"
            >
              <X className="h-4 w-4 text-[color:var(--muted)]" />
            </span>
          ) : null}
          <ChevronDown className={cn("h-4 w-4 text-[color:var(--muted)] transition", open ? "rotate-180" : "")} />
        </div>
      </button>

      {open ? (
        <div className="absolute left-0 right-0 top-[44px] z-20 overflow-hidden rounded-2xl border border-[color:var(--line)] bg-[color:var(--paper)] shadow-[var(--shadow-2)]">
          <div className="border-b border-[color:var(--line)] p-2">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="输入菜名或标签…"
              className="h-10 w-full rounded-xl border border-[color:var(--line)] bg-[color:var(--paper)] px-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
              autoFocus
            />
          </div>

          <div className="max-h-72 overflow-auto p-2">
            {filtered.length === 0 ? <div className="px-2 py-3 text-sm text-[color:var(--muted)]">没有匹配的菜谱</div> : null}
            {filtered.map((i) => {
              const active = i.id === value;
              return (
                <button
                  key={i.id}
                  type="button"
                  onClick={() => {
                    onChange(i.id);
                    setOpen(false);
                  }}
                  className={cn(
                    "flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2 text-left text-sm transition",
                    active ? "bg-[color:var(--wash-2)]" : "hover:bg-[color:var(--wash)]",
                  )}
                >
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-medium">{i.title}</div>
                    {i.tags.length ? <div className="mt-0.5 truncate text-xs text-[color:var(--muted)]">{i.tags.join(" · ")}</div> : null}
                  </div>
                  {active ? <Check className="h-4 w-4 text-[color:var(--stamp)]" /> : null}
                </button>
              );
            })}
          </div>
        </div>
      ) : null}
    </div>
  );
}

